define([
	'./panellinkeditor/module',
], function () {
});
